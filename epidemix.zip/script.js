const app = new Vue({
  el: '#app',
  data: {
    message: 'Loading',
    ctx: document.getElementById("chart").getContext("2d"),
    infected,
    infectivity,//according to data from China and Italy COVID-19 spreads at rate 22% a day
    numberOfDays,
    predictedMortalityRate, //italy numbers
    totaldead: 0,
    dead: 0,
    chart: undefined,
  },
  created: function () {
    this.message = 'Epidemix v.0.1 vue.js';
    this.infected = "10, 21, 32, 44, 61";
    this.infectivity = 0.22;//according to data from China and Italy COVID-19 spreads at rate 22% a day
    this.numberOfDays = 10;
    this.predictedMortalityRate = 0.06; //italy numbers
    this.dead = [];
    this.totaldead = 0;

  },
  mounted: function () {
    this.drawchart();
  },

  methods: {
    predictedMortality(predictedInfected, predictedMortalityRate) {
      const pi = predictedInfected;
      const d = [];
      pi.forEach(inf => {
        d.push(Math.round(inf * predictedMortalityRate));
      });
      this.totaldead = d[d.length - 3];
      console.log(`*********************`)
      console.log(d[d.length - 3])
      return d;
    },
    trueInfectivityModel(infected) { //counts true infectivity rate based on real data
      let arr = [];
      arr = this.copy(infected);
      const result = Math.round((arr.reduce((a, b) => a + b, 0) / arr.length)) / 100;

      return result;
    },

    labelGenerator(arr) {
      let result = [];
      for (let i = 1; i < arr.length - 1; i++) {
        result.push(`Day${i}`);
      }

      return result;
    },
    copy(array) {
      let arr = [];
      let json = JSON.stringify(array);
      arr = JSON.parse(json);
      let result = arr.split(',').map(Number);
      return result;
    },
    infectionModel(infected, infectionIndex, days) {
      let inf = [];
      inf = this.copy(infected);
      for (let day = 3; day < (days); day++) {
        //lets forward this 14 days into the future with 22% increase
        inf.push(
          Math.round(
            inf[inf.length - 1] +
            inf[inf.length - 1] * infectionIndex
          )
        );
      }
      //console.warn(inf)
      return inf;
    },

    drawchart: function () {
      const predictedInfected = this.infectionModel(
        this.infected,
        this.infectivity,
        this.numberOfDays
      );
      const trueInfectivity = this.trueInfectivityModel(this.infected);
      const trueInfections = this.infectionModel(
        this.infected,
        trueInfectivity,
        this.numberOfDays
      );
      const predictedDead = this.predictedMortality(
        trueInfections,
        this.predictedMortalityRate,
      );
      const labels = this.labelGenerator(predictedInfected);
      //-------------------------------------------------------------------------------------------------------------
      // result = [21, 32, 39, 48, 59, 72, 88, 107, 131, 160, 195, 238, 290, 354, 432, 527]; on 14.March prediction
      //-------------------------------------------------------------------------------------------------------------

      const chartData = {
        labels: labels,
        datasets: [
          {
            label: [`Cases so far`],
            data: this.copy(this.infected),
            fill: true,
            backgroundColor: "green", //blue,
            borderColor: "blue"
          },
          {
            label: [`World average  infectivity : ${this.infectivity * 100}%`],
            data: predictedInfected,
            fill: false,
            backgroundColor: "gray", //blue,
            borderColor: "gray"
          },
          {
            label: [
              `Estimated dead based on mortality rate ${this.predictedMortalityRate * 100}%`
            ],
            fill: false,
            backgroundColor: "red",
            borderColor: "red",
            data: predictedDead
          },
          {
            label: [`Current average infectivity : ${trueInfectivity * 100}%`],
            data: trueInfections,
            fill: false,
            backgroundColor: "blue", //blue,
            borderColor: "blue"
          },
        ]
      };

      if (
        this.chart !== undefined
        &&
        this.chart !== null
      ) {
        this.chart.destroy();
      }

      this.chart = new Chart(this.ctx, {
        type: "line",
        data: chartData,
        options: {}
      });

    }
  }
});









//console.log(chart1)